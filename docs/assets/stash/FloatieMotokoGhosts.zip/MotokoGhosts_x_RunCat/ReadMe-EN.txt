


	👻 Motoko Ghosts × RunCat Self-made Runner! 👻


⸻


This image is a fan-made project based on the original design of “Motoko Ghosts”,
an NFT collection on the ICP ecosystem. 💖

I’m just a fan of the unique and timeless design of Motoko Ghosts,
and I couldn’t resist making a Self-made Runner for RunCat!


⸻


💡 Highlights
	•	🖼️ Based on Motoko Ghosts NFT #1 Original
	•	🎨 A non-official fan project — not affiliated with Dfinity or the creators
	•	🐾 Usable as a Self-made Runner for RunCat, available on both Mac and Windows!
	•	💸 The Self-made feature in RunCat is paid (one-time purchase & reasonably priced!)
	•	🔍 Carefully crafted to look sharp and clean in menu bar size (60px x 36px!)


⸻


⚖️ Copyright & Credits
	•	This is a non-commercial fan project made out of love and respect for Motoko Ghosts.
	•	All artwork in the Motoko Ghosts collection is tied to ownership of each NFT.
	•	The original rights belong to the artists and project team, including the Dfinity Foundation.
	•	This asset is not intended for resale or redistribution — personal use within RunCat only.


⸻


🧡 Special Thanks
	•	Dfinity Foundation & Motoko Ghosts creators – Thank you for the amazing universe!
	•	RunCat developer – Thank you for such a customizable and delightful app!



⸻


